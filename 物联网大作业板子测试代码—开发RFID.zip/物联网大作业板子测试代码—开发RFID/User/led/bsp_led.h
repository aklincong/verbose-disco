#ifndef _BSP_LED_H
#define	_BSP_LED_H

#include "stm32f10x.h"

#define OPEN_LED_R			{GPIO_SetBits(GPIOB,GPIO_Pin_7),GPIO_SetBits(GPIOB,GPIO_Pin_8),GPIO_ResetBits(GPIOB,GPIO_Pin_9);}
#define OPEN_LED_G			{GPIO_SetBits(GPIOB,GPIO_Pin_7),GPIO_SetBits(GPIOB,GPIO_Pin_9),GPIO_ResetBits(GPIOB,GPIO_Pin_8);}
#define OPEN_LED_B			{GPIO_SetBits(GPIOB,GPIO_Pin_8),GPIO_SetBits(GPIOB,GPIO_Pin_9),GPIO_ResetBits(GPIOB,GPIO_Pin_7);}
#define CLOSE_LED 			{GPIO_SetBits(GPIOB,GPIO_Pin_7),GPIO_SetBits(GPIOB,GPIO_Pin_8),GPIO_SetBits(GPIOB,GPIO_Pin_9);}
void LED_GPIO_Config(void);

#endif /* _BSP_LED_H */
