#include "stm32f10x.h"
#include "stdio.h"
#include "bsp_led.h"
#include "bsp_key.h"
#include "bsp_beep.h"
#include "bsp_rfid.h"
#include "bsp_usart.h"

void InitializeSystem()
{
	CLOSE_LED;
	delay_10ms(10);
	PcdReset();
	PcdAntennaOff(); 
	PcdAntennaOn();  
	M500PcdConfigISOType( 'A' );
	OPEN_LED_B;
	delay_10ms(10);	
	CLOSE_LED;
	delay_10ms(10);
	OPEN_LED_B;
	delay_10ms(10);	
	CLOSE_LED;
}


int main(void)
{	
	char status,i;
	unsigned char snr, buf[16], TagType[2], SelectedSnr[4], DefaultKey[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},ysk[4]={0X53,0X16,0XF3,0X96}; 
	
	LED_GPIO_Config();	
	KEY_GPIO_Config();	
	BEEP_GPIO_Config();
	USART_Config();
	GPIO_ini();
	
	InitializeSystem( );	
	
  while (1)
  {
		status= PcdRequest(REQ_ALL,TagType);
		if(!status)
		{
			status = PcdAnticoll(SelectedSnr);
			if(!status)
			{
				status=PcdSelect(SelectedSnr);
				if(!status)
				{
					for(i=0;i<4;i++)
					{
						if(SelectedSnr[i] == ysk[i])
						{
							if(i==3 && SelectedSnr[3] == ysk[3])
							{
								printf("����ʶ��ɹ�,��ӭ�ؼң�\r\n");
								OPEN_LED_G;
								WaitCardOff();
							}
						}
						else
						{
							printf("����ʶ��ʧ�ܣ������ԣ�\r\n");
							OPEN_LED_R;
							WaitCardOff();
							break;
						}
					}
				}
			}
		}	
		OPEN_LED_B; 
	}
}


